package org.example;

public class Main {
    public static void main(String[] args) {
        // Create processes
        Process p1 = new Process(1, 0, 10);
        Process p2 = new Process(2, 3, 5);
        Process p3 = new Process(3, 5, 8);
        Process p4 = new Process(4, 6, 2);

        // Create scheduler
        Scheduler scheduler = new Scheduler(2);

        // Add processes to scheduler
        scheduler.addProcess(p1);
        scheduler.addProcess(p2);
        scheduler.addProcess(p3);
        scheduler.addProcess(p4);

        // Schedule processes
        scheduler.schedule();
        // Print process stats
        scheduler.printProcessStats();

    }
}
