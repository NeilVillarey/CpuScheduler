package org.example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class Scheduler {
    private Queue<Process> readyQueue;
    private int currentTime;
    private int timeQuantum;
    private Set<Process> scheduledProcesses;

    public Scheduler(int timeQuantum) {
        this.readyQueue = new LinkedList<Process>();
        this.currentTime = 0;
        this.timeQuantum = timeQuantum;
        this.scheduledProcesses = new HashSet<Process>();
    }

    public void addProcess(Process p) {
        readyQueue.add(p);
    }

    public void schedule() {
        scheduledProcesses.clear(); // Clear the set before scheduling processes
        while (!readyQueue.isEmpty()) {
            Process p = readyQueue.poll();
            int remainingTime = p.getRemainingTime();
            int timeSlice = Math.min(remainingTime, timeQuantum);
            p.setRemainingTime(remainingTime - timeSlice);
            currentTime += timeSlice;

            if (p.getRemainingTime() == 0) {
                p.setCompletionTime(currentTime);
                p.setTurnaroundTime(p.getCompletionTime() - p.getArrivalTime());
                p.setWaitingTime(p.getTurnaroundTime() - p.getBurstTime());
            } else {
                readyQueue.add(p);
            }

            scheduledProcesses.add(p); // Add process to the set of scheduled processes
        }
    }

    public void printProcessStats() {
        System.out.println("PID\tCompletion Time\tTurnaround Time\tWaiting Time");
        for (Process p : scheduledProcesses) {
            int completionTime = p.getCompletionTime() == -1 ? currentTime : p.getCompletionTime();
            int turnaroundTime = completionTime - p.getArrivalTime();
            int waitingTime = turnaroundTime - p.getBurstTime();
            System.out.println(p.getPid() + "\t" + completionTime + "\t\t" + turnaroundTime + "\t\t" + waitingTime);
        }
    }
}
